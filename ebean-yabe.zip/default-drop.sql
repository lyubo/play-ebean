drop table if exists Comment;
drop table if exists Post_Tag;
drop table if exists Tag;
drop table if exists Post;
drop table if exists User;
