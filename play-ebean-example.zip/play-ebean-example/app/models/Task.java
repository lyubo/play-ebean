package models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.avaje.ebean.Query;

import play.*;
import play.data.validation.Required;
import play.modules.ebean.EbeanSupport;

@Entity
public class Task extends EbeanSupport
{
  @Id
  @GeneratedValue
  public long    id;
  @Required
  public String  title;
  public boolean done;

  public Task(String title)
  {
    this.title = title;
  }

}
