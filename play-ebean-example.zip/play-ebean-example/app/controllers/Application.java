package controllers;

import java.util.List;

import models.Task;

import com.avaje.ebean.Ebean;

import play.modules.ebean.EbeanContext;
import play.mvc.*;

import static play.modules.ebean.EbeanSupport.Query;

public class Application extends Controller
{

  public static void index()
  {
    List<Task> tasks = Query(Task.class).orderBy("id desc").findList();
    render(tasks);
  }

  public static void createTask(String title)
  {
    Task task = new Task(title).save();
    renderJSON(task);
  }
  
  public static void changeStatus(Long id, boolean done)
  {
    Task task = Task.findById(id);
    task.done = done;
    task.save();
    renderJSON(task);
  }

}
